"""
Python functions for manipulating molecular graphs

In theory much of the functionality in here should be migrating into the
C/C++ codebase.

"""
from __future__ import annotations
import numpy as numpy
from rdkit import Chem
from rdkit import DataStructs
import types as types
__all__: list[str] = ['CharacteristicPolynomial', 'Chem', 'DataStructs', 'numpy', 'types']
def CharacteristicPolynomial(mol, mat = None):
    """
    calculates the characteristic polynomial for a molecular graph
    
    if mat is not passed in, the molecule's Weighted Adjacency Matrix will
    be used.
    
    The polynomial is expanded from the eigenvalues of the matrix, with the
    roots multiplied in order of increasing magnitude.
    
    The Le Verrier-Faddeev-Frame method previously used here (described in
    _Chemical Graph Theory, 2nd Edition_ by Nenad Trinajstic, CRC Press, 1992,
    pg 76) is a sequential recursion: coefficient k is produced after k matrix
    products have grown the intermediates to the magnitude of the largest
    coefficient, and is then obtained as a difference of quantities of that
    size. Beyond roughly 80 atoms float64 has no significant digits left, and
    because each coefficient feeds the next matrix the error amplifies. For a
    120-atom chain the true final coefficient is +1 and the recursion returned
    -1.97e26. Nothing overflows, so the failure was silent.
    
    """
